CREATE TRIGGER tr2
  AFTER INSERT
  ON users
  FOR EACH ROW
  begin
	insert into groups values (default, concat('grouplll2 ', current_time()));
end;

