CREATE TRIGGER tr1
  AFTER INSERT
  ON users
  FOR EACH ROW
  begin
	insert into groups values (default, concat('groupkk ', current_time()));
end;

